#ifndef FUN_SUB
#define FUN_SUB

int functionSubtract(int a, int b);

#endif