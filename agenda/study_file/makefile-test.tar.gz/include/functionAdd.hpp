#ifndef FUN_ADD
#define FUN_ADD

int functionAdd(int a, int b);

#endif