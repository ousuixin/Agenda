#include "functionSubtract.hpp"

int functionSubtract(int a, int b) {
    return a - b;
}